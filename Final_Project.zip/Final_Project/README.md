# This webapp shows articles posted by users regarding SVNIT classified by which campus building it relates to. Articles are displayed via markers on top of campus buildings using google maps API. 

To use this application,
Install all requirements,
# pip install -r requirements.txt
In the directory of final project, run the following commands
# export FLASK_APP = "application.py"
# export SECRET_KEY =  "secret key"
This is a secret key used to authorize requests 
# export MAIL_USERNAME = "example@example.com"
 This is the admin email account email to send confirmation emails 
# export MAIL_PASSWORD = "password"
This is the admin email account Password 
# export API_KEY = "APIKEY"
This is the Google Maps API Key
To run, from the command line in the Final_Project directory, use the following command:
# FLASK run
